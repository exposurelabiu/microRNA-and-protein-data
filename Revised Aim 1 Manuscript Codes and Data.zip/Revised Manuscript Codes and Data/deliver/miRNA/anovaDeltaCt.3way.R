#!/usr/bin/evn R
require(plyr)
library(dplyr)
library(tidyverse)
library(broom)
library(ggplot2)
library(ggpubr)
library(openxlsx)
library(rstatix)
library(NMF)
library(reshape)
library(gplots)
library(RColorBrewer)
library(pheatmap)
library(ggrepel)
library(limma)

lnames <- load("forLimma.RData")
groups=read.csv("groups.csv")
samplenames=c(groups$RID)
miRNAid=read.csv("miRNAlist.csv")
miRNAid=miRNAid[,1]
miRNAid <- gsub("-","_",miRNAid)

Expvalues <- dCtLimmaMatrix[miRNAid,]
colnames(Expvalues)=samplenames
rownames(groups) <- groups$Sample.ID
groups$Exposure <- substr(groups$Treatment,1,3)
groups$Chromosomal <- substr(groups$Treatment,5,6)
groups$Gonadal <- substr(groups$Treatment,7,7)
groups$Gonadal <- ifelse(groups$Gonadal=="M","Male","Female")
groups$Treatment <- factor(groups$Treatment, levels = c("PBS XXM", "PBS XXF", "PBS XYM", "PBS XYF", "HDM XXM", "HDM XXF", "HDM XYM","HDM XYF"))
groups$Exposure <- factor(groups$Exposure, levels=c("PBS","HDM"))
groups$Chromosomal <- factor(groups$Chromosomal, levels=c("XX","XY"))
groups$Gonadal <- factor(groups$Gonadal, levels=c("Female","Male"))
groups$group <- factor(groups$group, levels = c("XMP", "XFP", "YMP", "YFP", "XMH", "XFH", "YMH", "YFH"))

groupsReorder <- groups[order(groups$Treatment),]
ExpvaluesReorder <- Expvalues[,groupsReorder$RID]
groups <- groupsReorder
Expvalues <- ExpvaluesReorder
Expvalues.anova <- t(Expvalues)
groups.anova <- groups
rownames(groups.anova) <- groups.anova$RID
Expvalues.anova <- merge(Expvalues.anova,groups.anova,by=0,sort=F)
Expvalues.anova <- Expvalues.anova[,-1]
rownames(Expvalues.anova) <- Expvalues.anova$RID
Expvalues.anova$TestGroup <- ifelse(grepl("PBS",Expvalues.anova$Treatment),"Control","Test")
Expvalues.anova$TestGroup <- factor(Expvalues.anova$TestGroup, levels=c("Control","Test"))

plotExpValues <- t(Expvalues)
plotExpValues <- merge(plotExpValues,groups,by.x=0,by.y="RID",sort=F)
plotExpValues$TestGroup <- ifelse(grepl("PBS",plotExpValues$Treatment),"Control","Test")
plotExpValues$TestGroup <- factor(plotExpValues$TestGroup, levels=c("Control","Test"))

cairo_pdf("deltaCt_limma_plots.pdf", onefile=TRUE)
sampleDists <- dist( t( Expvalues ) )
sampleDistMatrix <- as.matrix( sampleDists )
rownames(sampleDistMatrix) <- paste(groups$Sample.ID,":",groups$Treatment,sep="")
colnames(sampleDistMatrix) <- paste(groups$Sample.ID,":",groups$Treatment,sep="")
ph <- pheatmap(sampleDistMatrix, color = greenred(256), border_color = NA, main="Sample vs Sample", fontsize_row=6, fontsize_col=6, show_rownames=TRUE, cluster_cols=TRUE, scale="none")
pca <- prcomp(t(na.omit(Expvalues)))
percentVar <- pca$sdev^2/sum(pca$sdev^2)
data <- cbind(pca$x,data.frame(Treatment=groups$Treatment, name = groups$Sample.ID ))
attr(data, "percentVar") <- percentVar

percentVar <- round(100 * attr(data, "percentVar"))
print(ggplot(data, aes(PC1, PC2, color=Treatment, label=name)) + geom_text_repel(max.overlaps = 14, box.padding = 0.5, min.segment.length = 0, size=2) +
        geom_point(size=3) + ggtitle("PC1 vs PC2") + xlab(paste0("PC1: ",percentVar[1],"% variance")) + ylab(paste0("PC2: ",percentVar[2],"% variance")) +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) )

mat <- Expvalues
colnames(mat) <- paste(groups$Sample.ID,":",groups$Treatment,sep="")
df <- data.frame(Treatment=groups$Treatment)
rownames(df) <- colnames(mat)
mycols <- brewer.pal(8, "Dark2")[1:length(unique( df$Treatment ))]
ann_colors <- list(Treatment=c(mycols))
names(ann_colors$Treatment) <- unique(df$Treatment)
title <- "∆Ct Values Heatmap"
ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = df, annotation_colors = ann_colors, border_color = NA, main=title, fontsize_row=6, fontsize_col=6, show_rownames=TRUE, cluster_cols=FALSE, scale="row")
ph <- pheatmap(mat, color = colorRampPalette(c("navy", "white", "red"))(256), annotation_col = df, annotation_colors = ann_colors, border_color = NA, main=title, fontsize_row=6, fontsize_col=6, show_rownames=TRUE, cluster_cols=TRUE, scale="row")

################ Limma ################
###### Same As Previous Analysis ######
design=model.matrix(~0 + groups$group)
colnames(design)=gsub("groups\\$group","",colnames(design))
rownames(design)=groups$RID

fit=lmFit(Expvalues,design)
contrast.matrix=makeContrasts(YM_HDMvPBS=YMH-YMP, XM_HDMvPBS=XMH-XMP, XF_HDMvPBS=XFH-XFP, YF_HDMvPBS=YFH-YFP, levels=design)
fit=contrasts.fit(fit,contrast.matrix)
fit=eBayes(fit, trend = TRUE)

makeBoxPlot <- function(plotExpValues, miRNA) {
  print(ggplot(plotExpValues, aes(x=Treatment,y=!!sym( miRNA ))) + geom_boxplot(aes(color=Treatment, fill=Treatment), alpha=0.3)  + stat_boxplot(geom ='errorbar',aes(color=Treatment)) + geom_point() + facet_wrap(vars(TestGroup),scales="free_x") + guides(alpha="none") + ylab("miRNA Expression (∆Ct)") + labs(title=miRNA) + theme(plot.title=element_text(hjust=0.5),axis.text.x=element_text(size=8)))
}

#RESULTS - top tables of miRNA comparisons
###########################################
#1) HDM vs PBS XYM
YM_HDMvPBS=topTable(fit, coef = "YM_HDMvPBS", sort.by="p", adjust.method = "fdr", genelist=miRNAid, n=Inf)
write.table(YM_HDMvPBS,file="YM_HDMvPBS.deltaCtLimma.tsv", quote=FALSE, sep="\t", na="NA", col.names=NA)

volcanoplot(fit, coef = "YM_HDMvPBS", style = "p-value")
#boxplot top 3 miRNAs
makeBoxPlot(plotExpValues,miRNA= rownames(YM_HDMvPBS[1,]))
makeBoxPlot(plotExpValues,miRNA= rownames(YM_HDMvPBS[2,]))
makeBoxPlot(plotExpValues,miRNA= rownames(YM_HDMvPBS[3,]))
###########################################

#2) HDM vs PBS XXM
XM_HDMvPBS=topTable(fit, coef = "XM_HDMvPBS", sort.by="p", adjust.method = "fdr", genelist=miRNAid, n=Inf)
write.table(XM_HDMvPBS,file="XM_HDMvPBS.deltaCtLimma.tsv", quote=FALSE, sep="\t", na="NA", col.names=NA)

volcanoplot(fit, coef = "XM_HDMvPBS", style = "p-value")
#boxplot top 3 miRNAs
makeBoxPlot(plotExpValues,miRNA= rownames(XM_HDMvPBS[1,]))
makeBoxPlot(plotExpValues,miRNA= rownames(XM_HDMvPBS[2,]))
makeBoxPlot(plotExpValues,miRNA= rownames(XM_HDMvPBS[3,]))
###########################################

#3) HDM vs PBS XXF
XF_HDMvPBS=topTable(fit, coef = "XF_HDMvPBS", sort.by="p", adjust.method = "BH", genelist=miRNAid, n=Inf)
write.table(XF_HDMvPBS,file="XF_HDMvPBS.deltaCtLimma.tsv", quote=FALSE, sep="\t", na="NA", col.names=NA)

volcanoplot(fit, coef = "XF_HDMvPBS", style = "p-value")
#boxplot top 3 miRNAs
makeBoxPlot(plotExpValues,miRNA= rownames(XF_HDMvPBS[1,]))
makeBoxPlot(plotExpValues,miRNA= rownames(XF_HDMvPBS[2,]))
makeBoxPlot(plotExpValues,miRNA= rownames(XF_HDMvPBS[3,]))
###########################################

#4) HDM vs PBS XYF
YF_HDMvPBS=topTable(fit, coef = "YF_HDMvPBS", sort.by="p", adjust.method = "BH", genelist=miRNAid, p.value=1, n=Inf)
write.table(YF_HDMvPBS,file="YF_HDMvPBS.deltaCtLimma.tsv", quote=FALSE, sep="\t", na="NA", col.names=NA)

volcanoplot(fit, coef = "YF_HDMvPBS", style = "p-value")
#boxplot top 3 miRNAs
makeBoxPlot(plotExpValues,miRNA= rownames(YF_HDMvPBS[1,]))
makeBoxPlot(plotExpValues,miRNA= rownames(YF_HDMvPBS[2,]))
makeBoxPlot(plotExpValues,miRNA= rownames(YF_HDMvPBS[3,]))
#################
#let7i
# miRNAid[8]
#Used in manuscript
miRNA <- "mmu_let_7i_5p"
  print(ggplot(plotExpValues, aes(x=Treatment,y=!!sym( miRNA ))) + geom_boxplot(aes(color=Treatment, fill=Treatment), alpha=0.3)  + stat_boxplot(geom ='errorbar',aes(color=Treatment)) + geom_point() + facet_wrap(vars(TestGroup),scales="free_x") + guides(alpha="none") + ylab("miRNA Expression (∆Ct)") + labs(title="Let-7i expression in the 4 core genotypes") + theme(plot.title=element_text(hjust=0.5),axis.text.x=element_text(size=8)))
dev.off()

################ ANOVA ################
############ MAIN RESULTS #############
anovaTests <- list()
anovaList <- list()
shapiroList <- list()
cairo_pdf("miRNA_anova_plots.pdf", onefile=TRUE)
for(i in miRNAid){
  print(i)
  ploti <- gsub("\\.","-",i)
  print(paste("testing ",i,sep=""))
  test <- aov(Expvalues.anova[,i] ~ Exposure*Gonadal*Chromosomal, data = Expvalues.anova)
  anovaList[[ i ]] <- data.frame(miRNA=i,broom::tidy(test))
# test normality
  stest <- shapiro.test(test$residuals)
  if(exists("shapiro")){
    shapiro <- rbind.fill(shapiro,data.frame(miRNA=i,broom::tidy(stest)))
  }else{
    shapiro <- data.frame(miRNA=i,broom::tidy(stest))
  }
  model <-  lm(Expvalues.anova[,i] ~ Exposure*Gonadal*Chromosomal, data = Expvalues.anova)
  sw <- Expvalues.anova %>% group_by(Exposure, Gonadal, Chromosomal) %>% shapiro_test(i)
  shapiroList[[i]] <- sw

# Create a QQ plot of residuals
  print(ggqqplot(residuals(model),title=paste(ploti," Residuals QQ Plot",sep="")))
  print(ggqqplot(Expvalues.anova, i, ggtheme = theme_bw(), title=paste(ploti," QQ Plot By Groups",sep="")) + facet_grid(Gonadal + Chromosomal ~ Exposure, labeller = "label_both"))
  par(mfrow=c(2,2))
  plot(test,main=ploti)
  par(mfrow=c(1,1))
  hist(test$residuals,main=paste(ploti," ANOVA Residuals Histogram",sep=""), xlab=paste(ploti," ANOVA Residuals",sep=""))
  anovaTests[[i]] <- test

  print(ggplot(Expvalues.anova, aes(x=Treatment,y=!!sym(i))) + geom_boxplot(aes(color=Treatment, fill=Treatment), alpha=0.3) + geom_point() + facet_wrap(vars(TestGroup),scales="free_x") + guides(alpha="none") + ylab("∆Ct") + labs(title=paste(ploti," ∆Ct",sep="")) + theme(plot.title=element_text(hjust=0.5),axis.text.x=element_text(size=8)))

  print(ggplot(Expvalues.anova, aes(x=Exposure,y=!!sym(i))) + geom_boxplot(aes(color=Chromosomal, fill=Chromosomal), alpha=0.3) + facet_wrap(vars(Gonadal),scales="free_x") + guides(alpha="none") + ylab("∆Ct") + labs(title=paste(ploti," ∆Ct",sep="")) + theme(plot.title=element_text(hjust=0.5),axis.text.x=element_text(size=8)))
}
write.xlsx(anovaList, file = "miRNA_ANOVA.xlsx",overwrite=TRUE)
write.table(shapiro,file="miRNA_ANOVA.shapiro.tsv", quote=FALSE, sep="\t", na="NA", row.names=FALSE)
write.xlsx(shapiroList,file="miRNA_ANOVA.shapiroByGroupsTest.xlsx", overwrite=TRUE)

dev.off()
save(anovaTests,anovaList,Expvalues.anova,file="anovaTests.RData")
writeLines(capture.output(sessionInfo()), "sessionInfo.miRNA_qPCR_ANOVA.txt")
