require(plyr)
library(dplyr)
library(tidyverse)
library(broom)
library(ggplot2)
library(ggpubr)
library(openxlsx)
library(rstatix)
cyto <- read.table("cytokine_average_ANOVA_input.tsv", sep="\t",header=TRUE,row.name=1,na.strings="NA")

groups <- read.csv("./groups.csv",header=TRUE)
rownames(groups) <- groups$Sample
groups$Exposure <- substr(groups$Treatment,1,3)
groups$Chromosomal <- substr(groups$Treatment,5,6)
groups$Gonadal <- substr(groups$Treatment,7,7)
groups$Gonadal <- ifelse(groups$Gonadal=="M","Male","Female")
groups$Treatment <- factor(groups$Treatment, levels = c("PBS_XXM", "PBS_XXF", "PBS_XYM", "PBS_XYF", "HDM_XXM", "HDM_XXF", "HDM_XYM","HDM_XYF"))
groups$Exposure <- factor(groups$Exposure, levels=c("PBS","HDM"))
groups$Chromosomal <- factor(groups$Chromosomal, levels=c("XX","XY"))
groups$Gonadal <- factor(groups$Gonadal, levels=c("Female","Male"))

tube2sample <- read.table("tube2sample.tsv", sep="\t",header=TRUE,row.name=1)
cyto2 <- merge(tube2sample,cyto,by=0,sort=F)
rownames(cyto2) <- cyto2$Sample
cyto2 <- subset(cyto2,select=-c(Row.names,Sample))


cyto_names <- names(cyto2)
cytoplot <- merge(cyto2,groups,by=0,sort=F)
cytoplot$TestGroup <- gsub("_Group_\\d+","",cytoplot$Experimental)
cytoplot$TestGroup <- factor(cytoplot$TestGroup, levels=c("Control","Test"))

logCyto <- log2(cyto2)
logcytoplot <- merge(logCyto,groups,by=0,sort=F)
logcytoplot$TestGroup <- gsub("_Group_\\d+","",logcytoplot$Experimental)
logcytoplot$TestGroup <- factor(logcytoplot$TestGroup, levels=c("Control","Test"))

anovaTests <- list()
anovaList <- list()
shapiroList <- list()
cairo_pdf("cytokine_anova_plots.pdf", onefile=TRUE)

for(i in cyto_names){
  print(i)
  ploti <- gsub("\\.","-",i)
  natest <- logcytoplot %>% group_by(Treatment) %>% dplyr::summarize(count_na = sum(! is.na(!!sym(i))))
  natest2<- logcytoplot %>% group_by(Exposure, Gonadal, Chromosomal) %>% dplyr::summarize(count_na = sum(! is.na(!!sym(i))))
# Test is true if at least 1 PBS group has 2 or greater non-NA values AND if at least 1 HDM group has 2 or greater non-NA values. 
  if(sum(natest[grep("PBS",natest$Treatment),]$count_na >= 2) >= 1 & sum(natest[grep("HDM",natest$Treatment),]$count_na >= 2) >= 1){
    print(paste("testing ",i,sep=""))
    test <- aov(logcytoplot[,i] ~ Exposure*Gonadal*Chromosomal, data = logcytoplot)
    anovaList[[ i ]] <- data.frame(cyto=i,broom::tidy(test))
#   test normality
    stest <- shapiro.test(test$residuals)
    if(exists("shapiro")){
      shapiro <- rbind.fill(shapiro,data.frame(cyto=i,broom::tidy(stest)))
    }else{
      shapiro <- data.frame(cyto=i,broom::tidy(stest))
    }
    model <-  lm(logcytoplot[,i] ~ Exposure*Gonadal*Chromosomal, data = logcytoplot)
# Test normality in each group type of Exposure, Gonadal, and Chromosomal
# You need to have at least 3 samples with values in each group
    if(any(natest2$count_na < 3)){
      sw <- data.frame(ShapiroTest="Not Enough Samples Per Group to Perform")
    }else{
      sw <- logcytoplot %>% group_by(Exposure, Gonadal, Chromosomal) %>% shapiro_test(i)
    }
    shapiroList[[i]] <- sw

# Create a QQ plot of residuals
    print(ggqqplot(residuals(model),title=paste(ploti," Residuals QQ Plot",sep="")))
# Create a QQ plot of residuals for each group type
    print(ggqqplot(logcytoplot, i, ggtheme = theme_bw(), title=paste(ploti," QQ Plot By Groups",sep="")) + facet_grid(Gonadal + Chromosomal ~ Exposure, labeller = "label_both"))

    par(mfrow=c(2,2))
    plot(test,main=ploti)
    par(mfrow=c(1,1))
    hist(test$residuals,main=paste(ploti," ANOVA Residuals Histogram",sep=""), xlab=paste(ploti," ANOVA Residuals",sep=""))
    anovaTests[[i]] <- test
  }
  print(ggplot(cytoplot, aes(x=Treatment,y=!!sym(i))) + geom_boxplot(aes(color=Treatment, fill=Treatment), alpha=0.3) + geom_point() + facet_wrap(vars(TestGroup),scales="free_x") + guides(alpha="none") + ylab("Observed Concentration (pg/mL)") + labs(title=ploti) + theme(plot.title=element_text(hjust=0.5),axis.text.x=element_text(size=8)))
  if(sum(is.na(logcytoplot[[i]])) > 23 ){
    logcytoplot[[i]] <- as.logical(logcytoplot[[i]])
  }
  print(ggplot(logcytoplot, aes(x=Treatment,y=!!sym(i))) + geom_boxplot(aes(color=Treatment, fill=Treatment), alpha=0.3) + geom_point() + facet_wrap(vars(TestGroup),scales="free_x") + guides(alpha="none") + ylab("log2(Observed Concentration (pg/mL))") + labs(title=paste("log2(",ploti,")",sep="")) + theme(plot.title=element_text(hjust=0.5),axis.text.x=element_text(size=8)))

  print(ggplot(cytoplot, aes(x=Exposure,y=!!sym(i))) + geom_boxplot(aes(color=Chromosomal, fill=Chromosomal), alpha=0.3) + facet_wrap(vars(Gonadal),scales="free_x") + guides(alpha="none") + ylab("Observed Concentration (pg/mL)") + labs(title=ploti) + theme(plot.title=element_text(hjust=0.5),axis.text.x=element_text(size=8)))

  print(ggplot(logcytoplot, aes(x=Exposure,y=!!sym(i))) + geom_boxplot(aes(color=Chromosomal, fill=Chromosomal), alpha=0.3) + facet_wrap(vars(Gonadal),scales="free_x") + guides(alpha="none") + ylab("log2(Observed Concentration (pg/mL))") + labs(title=paste("log2(",ploti,")",sep="")) + theme(plot.title=element_text(hjust=0.5),axis.text.x=element_text(size=8)))
}
write.xlsx(anovaList, file = "cytokineANOVA.xlsx",overwrite=TRUE)
write.table(shapiro,file="cytokineANOVA.shapiro.tsv", quote=FALSE, sep="\t", na="NA", row.names=FALSE)
write.xlsx(shapiroList,file="cytokineANOVA.shapiroByGroupsTest.xlsx", overwrite=TRUE)

dev.off()
save(anovaTests,anovaList,cytoplot,logcytoplot,file="anovaTests.RData")
writeLines(capture.output(sessionInfo()), "sessionInfo.cytokineANOVA.txt")
