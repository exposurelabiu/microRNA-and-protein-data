#Using cytoplot and logcytoplot data set created in anovaCyto.3way.with.Imput.R

a <-cytoplot %>% pivot_longer(cols=c('GM.CSF', 'IFNγ', 'IL.1α', 'IL.1β',  'IL.2', 'IL.4', 'IL.5', 'IL.6', 'IL.7', 'IL.10', 'IL.12p70', 'IL.13', 'IL.17A', 'KC',        
                                       'LIX', 'MCP.1', 'MIP.2', 'TNFα'),
                                names_to='protein',
                                values_to='value')

#Generate summary stats for different four core based on PBS and HDM treatment
#Summary stats
library(dplyr)
#All mice in each exposure category

ddply(a, c("Exposure", "Treatment", "protein"), summarise,
      mean = mean(value, na.rm=TRUE), sd = sd(value, na.rm=TRUE), n=length(value))

#Conduct estimated marginal means
library(broom)
library(lme4)
library(lmerTest)
library(emmeans)
library(readxl)
###
#impute then run code

logcytoplot2<-logcytoplot %>% mutate_if(is.numeric, function(x) ifelse(is.na(x), min(x, na.rm = T), x))

###
res_aov <- aov((IL.7) ~ Exposure*Gonadal*Chromosomal,
               data = logcytoplot2)
summary(res_aov)
tukey<-TukeyHSD(res_aov); tukey

###
#males vs females
res_aov <- aov((KC) ~ Gonadal*Chromosomal*Exposure,
               data = logcytoplot2)
tukey<-TukeyHSD(res_aov); tukey
###
res_aov <- aov((IL.17A) ~ Gonadal*Chromosomal*Exposure,
               data = logcytoplot2)
tukey<-TukeyHSD(res_aov); tukey

#
res_aov <- aov((KC) ~ Treatment*Gonadal*Chromosomal,
               data = logcytoplot2)
tukey<-TukeyHSD(res_aov); tukey
#
res_aov <- aov((KC) ~ Exposure*Experimental*Chromosomal,
               data = logcytoplot2)
tukey<-TukeyHSD(res_aov); tukey
#
res_aov <- aov((KC) ~ Exposure*Gonadal*Chromosomal,
               data = logcytoplot2)
tukey<-TukeyHSD(res_aov); tukey

###
res_aov <- aov((IL.17A) ~ Treatment*Gonadal*Chromosomal,
               data = logcytoplot2)
tukey<-TukeyHSD(res_aov); tukey

#######


#Create graphical abstract figure

g<-ggplot(logcytoplot2, aes(Exposure, (KC) , fill =Exposure)) +
  geom_boxplot() +
  labs(x = "", y = "log KC in pg/ml", fill = "") +
  facet_wrap(~Chromosomal*Gonadal, scales = "free") + ggtitle("log KC (IL-8 homologue) concentrations in BALF")
g + theme_grey(base_size = 14)

aa<-g + theme_grey(base_size = 14)


h<-ggplot(logcytoplot2, aes(Exposure, (IL.17A) , fill =Exposure)) +
  geom_boxplot() +
  labs(x = "", y = "IL-17A in pg/ml", fill = "") +
  facet_wrap(~Chromosomal*Gonadal, scales = "free") + ggtitle("IL-17A concentrations in BALF")

bb<-h + theme_grey(base_size = 14)

ggarrange(
  aa, bb, labels = c("i)", "ii)"),
  common.legend = TRUE, legend = "bottom"
)