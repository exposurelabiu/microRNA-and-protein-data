library(broom)
library(lme4)
library(lmerTest)
library(emmeans)
library(readxl)
#actual Anova data from anovaDeltaCt3way.R
modelList <- lapply(miRNAid, function(resp){
  mF <- formula(paste(resp, "~ Exposure*Gonadal*Chromosomal"))
  model <- aov(mF, data=Expvalues.anova)
  attr(model, 'call')$formula <- mF
  model
})
vec <- c("Exposure", "Gonadal", "Chromosomal")
output.1 <- lapply(modelList, function(x) emmeans(x, specs = vec))
names(output.1) <- miRNAid
write.xlsx(output.1, file = "Output of Emmeans without pvalues.xlsx", overwrite = T)

output.2 <- lapply(modelList, function(x) contrast(emmeans(x, specs = vec), method = "revpairwise", by = c("Gonadal","Chromosomal")))
names(output.2) <- miRNAid
write.xlsx(output.2, file = "Output of Emmeans Reorder.xlsx", overwrite = T)